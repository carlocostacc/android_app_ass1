package com.example.assignement12;

public class history_item {
    String event_name;

    public history_item(String event_name) {
        this.event_name = event_name;
    }

    public String getEvent_name() {
        return event_name;
    }

    public void setEvent_name(String event_name) {
        this.event_name = event_name;
    }
}
