package com.example.assignement12;

public class Itemhistory {
    String value;

    public Itemhistory(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
